package com.mawsu3a.muhammad;

import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color; import android.view.*; import android.widget.*;

public class MainActivity extends Activity {
  TextView status;
  @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main); status=findViewById(R.id.status);
    findViewById(R.id.hadith).setOnClickListener(v->show("الأحاديث والروايات", "سيتم عرض الرواية فقط مع مصدرها وتفاصيل سندها وحكمها. إذا تعذر التحقق سيظهر: لم يتم العثور على مصدر موثوق لهذه الرواية بهذا اللفظ."));
    findViewById(R.id.maraji).setOnClickListener(v->show("فتاوى المراجع", "يجب أن يكون نص الفتوى من مصدر رسمي أو موثوق قابل للتحقق، مع فصل شرح الذكاء الاصطناعي عن النص الأصلي."));
    findViewById(R.id.moon).setOnClickListener(v->show("التقويم والهلال", "تُعرض بداية الشهر بحسب إعلان المرجع المعني، ولا يختار التطبيق مرجعاً بدلاً عن المستخدم."));
    findViewById(R.id.sources).setOnClickListener(v->show("المصادر والكتب", "قاعدة المصادر مصممة لحفظ اسم الكتاب والمؤلف والجزء والصفحة ورقم الحديث والرابط الأصلي."));
    findViewById(R.id.favorites).setOnClickListener(v->show("المفضلة", "يمكن لاحقاً حفظ الروايات والفتاوى والمصادر المفضلة محلياً."));
  }
  void show(String title,String msg){ new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("حسنًا",null).show(); }
}
